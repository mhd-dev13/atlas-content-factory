// ============================================================
// 🎬 ATLAS QUOTE RENDERER
// Burn Persian text on image using ffmpeg-micro @text-overlay
// ============================================================

const BASE_URL = "https://api.ffmpeg-micro.com";

const VIDEO_WIDTH = 1080;
const VIDEO_HEIGHT = 1920;
const FPS = 30;

const DEFAULT_DURATION = 8;
const MAX_DURATION = 15;

const POLL_INTERVAL = 2000;
const MAX_ATTEMPTS = 40;


// ============================================================
// ⏳ SLEEP
// ============================================================

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}


// ============================================================
// 🔐 AUTH
// ============================================================

function authHeaders(env) {
  if (!env?.FFMPEG_MICRO_API_KEY) {
    throw new Error("FFMPEG_MICRO_API_KEY_MISSING");
  }

  return {
    "Authorization": `Bearer ${env.FFMPEG_MICRO_API_KEY}`,
    "Content-Type": "application/json"
  };
}


// ============================================================
// 🧹 CLEAN TEXT
// ============================================================

function cleanText(value) {
  return String(value || "")
    .replace(/\r/g, "")
    .trim();
}


// ============================================================
// 📤 UPLOAD IMAGE
// ============================================================

async function uploadImage(env, imageBuffer) {

  if (!imageBuffer) {
    throw new Error("IMAGE_BUFFER_MISSING");
  }

  const fileSize = imageBuffer.byteLength;

  if (!fileSize) {
    throw new Error("IMAGE_BUFFER_EMPTY");
  }

  const filename = `atlas-quote-${Date.now()}.png`;

  // 1. Get presigned URL
  const response = await fetch(
    `${BASE_URL}/v1/upload/presigned-url`,
    {
      method: "POST",
      headers: authHeaders(env),
      body: JSON.stringify({
        filename,
        contentType: "image/png",
        fileSize
      })
    }
  );

  const data = await response.json();

  if (!response.ok) {
    throw new Error(`FFMPEG_UPLOAD_URL_FAILED:${JSON.stringify(data)}`);
  }

  const uploadUrl = data?.result?.uploadUrl;
  const serverFilename = data?.result?.filename;

  if (!uploadUrl || !serverFilename) {
    throw new Error("FFMPEG_UPLOAD_URL_INVALID");
  }

  // 2. Upload binary
  const uploadResponse = await fetch(uploadUrl, {
    method: "PUT",
    headers: {
      "Content-Type": "image/png"
    },
    body: imageBuffer
  });

  if (!uploadResponse.ok) {
    throw new Error(`FFMPEG_IMAGE_UPLOAD_FAILED:${uploadResponse.status}`);
  }

  // 3. Confirm
  const confirmResponse = await fetch(
    `${BASE_URL}/v1/upload/confirm`,
    {
      method: "POST",
      headers: authHeaders(env),
      body: JSON.stringify({
        filename: serverFilename,
        fileSize
      })
    }
  );

  const confirmData = await confirmResponse.json();

  if (!confirmResponse.ok) {
    throw new Error(`FFMPEG_UPLOAD_CONFIRM_FAILED:${JSON.stringify(confirmData)}`);
  }

  const fileUrl = confirmData?.result?.fileUrl;

  if (!fileUrl) {
    throw new Error("FFMPEG_FILE_URL_MISSING");
  }

  return {
    filename: serverFilename,
    fileUrl,
    fileSize
  };
}


// ============================================================
// 🎥 CREATE QUOTE JOB (image → short video with text overlay)
// ============================================================

async function createQuoteJob(env, fileUrl, text, duration) {

  const safeText = cleanText(text);

  // Use the high-level @text-overlay virtual option
  // which handles wrapping and styling better than raw ASS.
  const options = [
    {
      option: "-t",
      argument: String(duration)
    },
    {
      option: "-vf",
      argument: [
        `scale=${VIDEO_WIDTH}:${VIDEO_HEIGHT}:force_original_aspect_ratio=increase`,
        `crop=${VIDEO_WIDTH}:${VIDEO_HEIGHT}`,
        // very subtle slow zoom so it feels alive but almost static
        `zoompan=z='min(zoom+0.0005,1.04)':d=${duration * FPS}:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':s=${VIDEO_WIDTH}x${VIDEO_HEIGHT}:fps=${FPS}`
      ].join(",")
    },
    {
      option: "-c:v",
      argument: "libx264"
    },
    {
      option: "-preset",
      argument: "veryfast"
    },
    {
      option: "-pix_fmt",
      argument: "yuv420p"
    },
    {
      option: "-an"
    },
    // High-level text overlay (better Persian support hope)
    {
      option: "@text-overlay",
      argument: {
        text: safeText,
        style: {
          position: "center",
          fontSize: 52,
          fontColor: "#FFFFFF",
          outlineThickness: 3,
          outlineColor: "#000000",
          textWidth: 900
        }
      }
    }
  ];

  const body = {
    inputs: [
      {
        url: fileUrl,
        options: [
          { option: "-loop", argument: "1" },
          { option: "-framerate", argument: String(FPS) }
        ]
      }
    ],
    outputFormat: "mp4",
    options
  };

  console.log("ATLAS_QUOTE_JOB_BODY:", JSON.stringify(body, null, 2));

  const response = await fetch(
    `${BASE_URL}/v1/transcodes`,
    {
      method: "POST",
      headers: authHeaders(env),
      body: JSON.stringify(body)
    }
  );

  const data = await response.json();

  if (!response.ok) {
    throw new Error(`FFMPEG_TRANSCODE_FAILED:${JSON.stringify(data)}`);
  }

  const jobId = data?.result?.id || data?.id;

  if (!jobId) {
    throw new Error("FFMPEG_JOB_ID_MISSING");
  }

  console.log("ATLAS_QUOTE_JOB_CREATED:", jobId);

  return jobId;
}


// ============================================================
// ⏳ WAIT FOR JOB
// ============================================================

async function waitForVideo(env, jobId) {

  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {

    await sleep(POLL_INTERVAL);

    const response = await fetch(
      `${BASE_URL}/v1/transcodes/${jobId}`,
      {
        method: "GET",
        headers: {
          "Authorization": `Bearer ${env.FFMPEG_MICRO_API_KEY}`
        }
      }
    );

    const data = await response.json();

    const status = (
      data?.result?.status ||
      data?.status ||
      ""
    ).toLowerCase();

    console.log(`ATLAS_JOB_STATUS [${attempt}]:`, status);

    if (status === "completed" || status === "done" || status === "success") {
      return data;
    }

    if (status === "failed" || status === "error") {
      throw new Error(`FFMPEG_JOB_FAILED:${JSON.stringify(data)}`);
    }
  }

  throw new Error("FFMPEG_JOB_TIMEOUT");
}


// ============================================================
// 📥 GET DOWNLOAD URL
// ============================================================

async function getDownloadUrl(env, jobId) {

  const response = await fetch(
    `${BASE_URL}/v1/transcodes/${jobId}/download`,
    {
      method: "GET",
      headers: {
        "Authorization": `Bearer ${env.FFMPEG_MICRO_API_KEY}`
      }
    }
  );

  const data = await response.json();

  const url =
    data?.result?.url ||
    data?.url ||
    data?.result?.downloadUrl;

  if (!url) {
    throw new Error(`FFMPEG_DOWNLOAD_URL_MISSING:${JSON.stringify(data)}`);
  }

  return url;
}


// ============================================================
// 🎯 MAIN: RENDER QUOTE IMAGE
// ============================================================

export async function renderQuoteImage(env, imageBuffer, options = {}) {

  const duration = Math.max(
    5,
    Math.min(
      MAX_DURATION,
      Number(options.duration || DEFAULT_DURATION)
    )
  );

  const text = cleanText(options.text);

  if (!text) {
    throw new Error("QUOTE_TEXT_MISSING");
  }

  console.log("ATLAS_QUOTE_RENDER_START:", {
    duration,
    textPreview: text.slice(0, 80),
    imageBytes: imageBuffer?.byteLength
  });

  // 1. Upload background
  const uploaded = await uploadImage(env, imageBuffer);

  console.log("ATLAS_IMAGE_UPLOADED:", uploaded.fileUrl);

  // 2. Create job with text overlay
  const jobId = await createQuoteJob(
    env,
    uploaded.fileUrl,
    text,
    duration
  );

  // 3. Wait
  await waitForVideo(env, jobId);

  // 4. Get result
  const videoUrl = await getDownloadUrl(env, jobId);

  console.log("ATLAS_QUOTE_RENDER_COMPLETE:", {
    jobId,
    videoUrl,
    duration
  });

  return {
    jobId,
    videoUrl,
    duration,
    text
  };
}


// Keep old name for compatibility if anything still imports it
export async function renderImageToVideo(env, imageBuffer, options = {}) {
  return renderQuoteImage(env, imageBuffer, {
    text: options.hook || options.persianText || options.text || "",
    duration: options.duration
  });
}
