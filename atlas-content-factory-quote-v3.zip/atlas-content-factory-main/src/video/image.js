// ============================================================
// 🎨 ATLAS IMAGE GENERATOR
// Cloudflare Workers AI — Quote Background Style
// ============================================================

const IMAGE_MODEL =
  "@cf/black-forest-labs/flux-1-schnell";


// ============================================================
// 🖼️ GENERATE IMAGE
// ============================================================

export async function generateImage(
  env,
  prompt
) {

  if (!env?.AI) {
    throw new Error("CLOUDFLARE_AI_BINDING_MISSING");
  }

  if (!prompt || !String(prompt).trim()) {
    throw new Error("IMAGE_PROMPT_MISSING");
  }

  const finalPrompt = `
Vertical Instagram quote image background, 9:16 composition, 1080x1920.

${String(prompt).trim()}

Style requirements:
- Dark, moody, atmospheric
- Soft solid colors or very subtle gradients
- Preferred colors: deep teal, dark charcoal, midnight blue, soft black, muted forest
- Empty center space for typography
- Minimal texture, no busy details
- Cinematic soft lighting
- Peaceful and emotional atmosphere
- High quality, clean, premium look

STRICTLY FORBIDDEN:
- No text of any kind
- No letters, no words, no numbers
- No logos, no watermarks
- No UI elements
- No people, no faces
- No animals in the center
- No bright colors dominating the center

The image must leave a large clean dark area in the middle
so elegant white Persian text can be placed later.
  `.trim();


  console.log("ATLAS_IMAGE_GENERATION:", finalPrompt);


  try {

    const result = await env.AI.run(
      IMAGE_MODEL,
      {
        prompt: finalPrompt
      }
    );


    // Direct binary
    if (result instanceof ArrayBuffer) {
      return result;
    }

    if (result instanceof Uint8Array) {
      return result.buffer.slice(
        result.byteOffset,
        result.byteOffset + result.byteLength
      );
    }

    // Base64 response
    if (result && typeof result.image === "string") {
      const binary = Uint8Array.from(
        atob(result.image),
        char => char.charCodeAt(0)
      );
      return binary.buffer;
    }

    console.error("ATLAS_IMAGE_UNEXPECTED_RESPONSE:", result);
    throw new Error("IMAGE_GENERATION_UNEXPECTED_FORMAT");

  } catch (error) {
    console.error("ATLAS_IMAGE_ERROR:", error?.message || error);
    throw error;
  }
}
