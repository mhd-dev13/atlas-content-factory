// ============================================================
// 🎬 ATLAS QUOTE PIPELINE
// Persian Quote Image (text burned on image)
// ============================================================

import { generateQuote } from "../content/quote.js";
import { generateImage } from "../video/image.js";
import { renderQuoteImage } from "../video/renderer.js";
import { sendMessage, sendVideo, sendPhoto } from "../telegram/api.js";


// ============================================================
// 💾 JOB KEY
// ============================================================

function getReelKey(chatId) {
  return `atlas:quote:${chatId}`;
}


// ============================================================
// 💾 SAVE JOB
// ============================================================

async function saveJob(env, chatId, data) {
  if (!env?.ATLAS_KV) return;

  try {
    await env.ATLAS_KV.put(
      getReelKey(chatId),
      JSON.stringify({
        ...data,
        updatedAt: Date.now()
      }),
      { expirationTtl: 86400 }
    );
  } catch (error) {
    console.error("ATLAS_KV_SAVE_ERROR:", error?.message || error);
  }
}


// ============================================================
// 📡 PROGRESS
// ============================================================

async function progress(env, chatId, text) {
  try {
    await sendMessage(env, chatId, text);
  } catch (error) {
    console.error("ATLAS_PROGRESS_ERROR:", error?.message || error);
  }
}


// ============================================================
// 📝 BUILD CAPTION
// ============================================================

function buildCaption(quote) {
  const fa = String(quote?.caption_fa || "").trim();
  const en = String(quote?.caption_en || "").trim();

  return [
    "🇮🇷",
    fa,
    "",
    "🇬🇧",
    en
  ]
    .filter(Boolean)
    .join("\n")
    .trim();
}


// ============================================================
// 🎯 CREATE QUOTE IMAGE (main entry)
// ============================================================

export async function createReel(env, chatId) {

  const job = {
    status: "starting",
    startedAt: Date.now(),
    chatId
  };

  await saveJob(env, chatId, job);

  try {

    // --------------------------------------------------------
    // 1️⃣ GENERATE QUOTE TEXT
    // --------------------------------------------------------

    job.status = "quote";
    await saveJob(env, chatId, job);

    await progress(env, chatId, [
      "✍️ ATLAS QUOTE FACTORY",
      "",
      "🧠 مرحله ۱/۳",
      "در حال ساخت متن فارسی..."
    ].join("\n"));

    const quote = await generateQuote(env);

    job.quote = {
      on_screen_text: quote.on_screen_text,
      caption_fa: quote.caption_fa,
      caption_en: quote.caption_en,
      mood: quote.mood
    };

    await saveJob(env, chatId, job);

    await progress(env, chatId, [
      "✅ متن آماده شد",
      "",
      "🇮🇷",
      quote.on_screen_text
    ].join("\n"));


    // --------------------------------------------------------
    // 2️⃣ GENERATE BACKGROUND IMAGE
    // --------------------------------------------------------

    job.status = "image";
    await saveJob(env, chatId, job);

    await progress(env, chatId, [
      "🖼️ مرحله ۲/۳",
      "در حال ساخت پس‌زمینه اتمسفریک..."
    ].join("\n"));

    const imageBuffer = await generateImage(env, quote.visual);

    if (!imageBuffer || !imageBuffer.byteLength) {
      throw new Error("IMAGE_GENERATION_EMPTY");
    }

    job.imageBytes = imageBuffer.byteLength;
    await saveJob(env, chatId, job);


    // --------------------------------------------------------
    // 3️⃣ BURN PERSIAN TEXT ON IMAGE + RENDER
    // --------------------------------------------------------

    job.status = "render";
    await saveJob(env, chatId, job);

    await progress(env, chatId, [
      "✨ مرحله ۳/۳",
      "در حال چاپ متن فارسی روی تصویر...",
      "",
      "این مرحله ممکنه کمی طول بکشه."
    ].join("\n"));

    const rendered = await renderQuoteImage(
      env,
      imageBuffer,
      {
        text: quote.on_screen_text,
        duration: 8
      }
    );


    // --------------------------------------------------------
    // 4️⃣ SEND RESULT
    // --------------------------------------------------------

    const caption = buildCaption(quote);

    // Prefer sending as video (short static-style reel)
    // because the text is already burned in.
    if (rendered?.videoUrl) {
      await sendVideo(
        env,
        chatId,
        rendered.videoUrl,
        caption
      );
    } else if (rendered?.imageUrl) {
      await sendPhoto(
        env,
        chatId,
        rendered.imageUrl,
        caption
      );
    } else {
      throw new Error("RENDER_RESULT_EMPTY");
    }

    job.status = "done";
    job.finishedAt = Date.now();
    await saveJob(env, chatId, job);

  } catch (error) {

    console.error("QUOTE_PIPELINE_ERROR:", error?.stack || error);

    job.status = "error";
    job.error = String(error?.message || error);
    await saveJob(env, chatId, job);

    await sendMessage(env, chatId, [
      "⚠️ ساخت نقل‌قول با مشکل مواجه شد.",
      "",
      `🔧 ${error?.message || error}`
    ].join("\n"));
  }
}
