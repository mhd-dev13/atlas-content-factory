export const CONFIG = {
  botName: "Atlas",
  contentChannel: "@AtlasContentFactory",

  model: "@cf/qwen/qwen3-30b-a3b-fp8",

  maxTokens: 1200,
  temperature: 0.75,

  version: "3.0.0-quote"
};
