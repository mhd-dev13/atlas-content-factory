// ============================================================
// 🤖 ATLAS CONTENT FACTORY — ROUTER
// Quote Image Mode
// ============================================================

import {
  sendMessage,
  telegram
} from "./telegram/api.js";

import {
  createReel
} from "./reel/pipeline.js";


// ============================================================
// 🎛️ MAIN MENU
// ============================================================

async function sendMainMenu(env, chatId) {

  return telegram(env, "sendMessage", {
    chat_id: chatId,
    text: [
      "🤖 ATLAS CONTENT FACTORY",
      "",
      "🟢 سیستم آنلاین است.",
      "",
      "با یک دکمه یک نقل‌قول فارسی زیبا بساز:",
      "",
      "✍️ متن احساسی → تصویر تیره → چاپ متن روی عکس"
    ].join("\n"),

    reply_markup: {
      inline_keyboard: [
        [
          {
            text: "✍️ ساخت نقل‌قول",
            callback_data: "atlas_create_reel"
          }
        ],
        [
          {
            text: "📊 وضعیت",
            callback_data: "atlas_status"
          }
        ]
      ]
    }
  });
}


// ============================================================
// 📊 STATUS
// ============================================================

async function sendStatus(env, chatId) {

  await sendMessage(env, chatId, [
    "📊 ATLAS STATUS",
    "",
    "🟢 Worker: Online",
    "🧠 AI: Cloudflare Workers AI",
    "🖼️ Image: Flux",
    "✍️ Mode: Persian Quote Image",
    "",
    `نسخه: 3.0.0 — Quote Mode`
  ].join("\n"));
}


// ============================================================
// 🧭 ROUTE UPDATE
// ============================================================

export async function routeUpdate(update, env) {

  // ==========================================================
  // 🔘 CALLBACK QUERY
  // ==========================================================

  if (update?.callback_query) {

    const callback = update.callback_query;
    const callbackId = callback.id;
    const chatId = callback?.message?.chat?.id;
    const data = callback?.data;

    if (!chatId) return;

    // Answer callback
    try {
      await telegram(env, "answerCallbackQuery", {
        callback_query_id: callbackId
      });
    } catch (error) {
      console.error("ATLAS_CALLBACK_ERROR:", error?.message || error);
    }

    // ✍️ CREATE QUOTE
    if (data === "atlas_create_reel") {
      await createReel(env, chatId);
      return;
    }

    // 📊 STATUS
    if (data === "atlas_status") {
      await sendStatus(env, chatId);
      return;
    }

    return;
  }


  // ==========================================================
  // 💬 MESSAGE
  // ==========================================================

  const message = update?.message;

  if (!message?.chat?.id) return;

  const chatId = message.chat.id;
  const text = (message.text || "").trim();

  if (!text) return;

  // /start
  if (text === "/start") {
    await sendMainMenu(env, chatId);
    return;
  }

  // Any other message → show menu
  await sendMainMenu(env, chatId);
}
