// ============================================================
// ✍️ ATLAS QUOTE ENGINE
// Persian Quote Image Generator
// Style: deep_dari9 / _be_yar aesthetic
// ============================================================

import { generateAI } from "../ai/engine.js";


// ============================================================
// 📜 QUOTE RULES
// ============================================================

const QUOTE_RULES = `
You are Atlas Quote Writer.

Your job is to create beautiful, emotional,
multi-line Persian quotes for Instagram images.

STYLE (very important):

Write exactly in the style of popular Persian
quote accounts like deep_dari9 and _be_yar.

Characteristics:

- Deep, reflective, slightly melancholic or calm
- Natural modern Persian (not formal, not poetic old style)
- Multi-line (3 to 6 short lines)
- Emotionally honest
- About human feelings, relationships, loneliness,
  self-awareness, quiet moments, inner world
- No medical claims
- No motivational clichés
- No "آرامش خود را پیدا کنید" type phrases
- No emojis in the on-screen text

Good examples of tone:

"آدم‌ها مرا متفاوت می‌بینند؛
یکی مرا مهربان و صمیمی می‌داند،
دیگری مغرور یا کم‌حرف.
اما من همان آدم هستم؛
فقط رفتار دیگران باعث می‌شود
بخش‌های متفاوتی از شخصیتم نمایان شود."

"هیچ‌کس نمی‌داند
در دل دیگری چه می‌گذرد؛ شاید لبخندی که می‌بینی،
آخرین تلاش او برای فرو نریختن باشد..."

Rules for on_screen_text (Persian):

- 3 to 6 short lines
- Each line should feel natural when read alone
- Total length: maximum 90 characters ideally
- Must look elegant when centered on a dark image
- No hashtags, no emojis, no English inside the quote

caption_fa:
Natural Persian caption (1-2 sentences) that expands the feeling.

caption_en:
Natural English caption (1-2 sentences), not a literal translation.

visual:
Describe a dark, atmospheric, minimal background
that matches the emotional vibe of the quote.
Prefer solid dark colors, soft gradients, night sky,
fog, soft light, empty space in the center.
No people, no text, no logos.

Return ONLY valid JSON.
`;


// ============================================================
// 🎯 GENERATE QUOTE
// ============================================================

export async function generateQuote(env) {

  const messages = [

    {
      role: "system",
      content: QUOTE_RULES.trim()
    },

    {
      role: "user",
      content: `
Create ONE original Persian quote image content.

Return ONLY this JSON structure:

{
  "on_screen_text": "",
  "caption_fa": "",
  "caption_en": "",
  "visual": "",
  "mood": ""
}

on_screen_text must be multi-line Persian
(use \\n between lines).

Make it feel deep and real.
      `.trim()
    }

  ];


  const raw = await generateAI(env, messages);

  const quote = extractJSON(raw);

  // Safety fallbacks
  if (!quote.on_screen_text || !String(quote.on_screen_text).trim()) {
    quote.on_screen_text = "گاهی فقط باید چند لحظه\nاز همه چیز فاصله بگیری\nو فقط نفس بکشی.";
  }

  if (!quote.caption_fa) {
    quote.caption_fa = "گاهی سکوت، بهترین پاسخ است.";
  }

  if (!quote.caption_en) {
    quote.caption_en = "Sometimes silence is the most honest answer.";
  }

  if (!quote.visual) {
    quote.visual = "A deep dark teal solid background with soft subtle texture, empty center space, minimal atmospheric mood, cinematic lighting, no objects, no people.";
  }

  // Normalize newlines
  quote.on_screen_text = String(quote.on_screen_text)
    .replace(/\\n/g, "\n")
    .replace(/\r/g, "")
    .trim();

  return quote;
}


// ============================================================
// 🧠 EXTRACT JSON
// ============================================================

function extractJSON(text) {

  const cleaned = String(text || "")
    .replace(/```json/gi, "")
    .replace(/```/g, "")
    .replace(/<think>[\s\S]*?<\/think>/gi, "")
    .trim();

  // Try direct parse
  try {
    return JSON.parse(cleaned);
  } catch (_) {}

  // Try to find JSON object
  const match = cleaned.match(/\{[\s\S]*\}/);
  if (match) {
    try {
      return JSON.parse(match[0]);
    } catch (_) {}
  }

  // Fallback
  return {
    on_screen_text: "گاهی فقط باید چند لحظه\nاز همه چیز فاصله بگیری\nو فقط نفس بکشی.",
    caption_fa: "گاهی سکوت، بهترین پاسخ است.",
    caption_en: "Sometimes silence is the most honest answer.",
    visual: "A deep dark teal solid background with soft subtle texture, empty center space, minimal atmospheric mood, cinematic lighting, no objects, no people.",
    mood: "calm"
  };
}
